using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace inventory.Data
{
    public class ApplicationDbContext 
    {
       
       
      
    }

   

  

   
}