using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace inventory.Components.Account.Pages
{
    public class authModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
