﻿using System.ComponentModel.DataAnnotations;

namespace Ims.CoreBussiness
{
    public class Inventory
    {
        public int InventoryId {  get; set; }
        [Required]
        public string? InventoryName { get; set; } 

        public int Quantity { get; set; }

        public double price { get; set; }
    }
}
