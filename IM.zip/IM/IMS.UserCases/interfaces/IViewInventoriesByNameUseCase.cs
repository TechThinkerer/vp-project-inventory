﻿using Ims.CoreBussiness;

namespace IMS.UserCases
{
    public interface IViewInventoriesByNameUseCase
    {
        Task<IEnumerable<Inventory>> ExecuteAsync(string name);
    }
}