﻿using Ims.CoreBussiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMS.UserCases.Plugininterfaces
{
    public  interface IInventoryRepository
    {
        Task<IEnumerable<Inventory>>  GetInventoriesByName(string name);
    }
}
