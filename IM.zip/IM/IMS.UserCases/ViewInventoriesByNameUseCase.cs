﻿using Ims.CoreBussiness;
using IMS.UserCases.Plugininterfaces;

namespace IMS.UserCases
{
    public class ViewInventoriesByNameUseCase : IViewInventoriesByNameUseCase
    {
        private readonly IInventoryRepository inventoryRepository;

        public ViewInventoriesByNameUseCase(IInventoryRepository inventoryRepository)
        {
            this.inventoryRepository = inventoryRepository;


        }
        public async Task<IEnumerable<Inventory>> ExecuteAsync(string name= " ")
        {

            return await this.inventoryRepository.GetInventoriesByName(name);
        }

    }

    public interface IInventoryRepository
    {
        Task<IEnumerable<Inventory>> GetInventoriesByName(string name);
    }
}
